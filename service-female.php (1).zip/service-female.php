<!doctype html>
<html lang="en">
   <head>
      <!-- header CDN links -->
      <?php include 'includes/header.php'?>
      <!-- header CDN links -->
      <title>Salon for Women in Noida | Makeup, waxing, Nail art, Bridal makeup services in noida - Gliss</title>
      <meta name="description" content="Our unisex salon offers services like bridal makeup, party makeup, facials, waxing and skincare treatments for women. We provide special offers on Manicure Pedicure, Smoothening, Salon Packages, Nail Art at an affordable price." />
      <!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=AW-340902858"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
        
          gtag('config', 'AW-340902858');
        </script>
   </head>
   <body>
      <!-- navigation bar -->
      <?php include 'includes/navbar.php'?>
      <!-- navigation bar -->
      <section class="main_top_section_two">
        <div class="main_top_section_after_female">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-6">
                <!-- <div class="inner_male_photo">
                  
                </div> -->
              </div>
              <div class="col-md-5 ms-auto d-flex align-items-center justify-content-center">
                <div>
                  <h1 class="display-3 text-center text-white">Gliss, India’s Smartest Salon</h1>
                   <div class="m-auto text-center"><a href="service-male" class="btn text-white">Men</a> | <a href="service-female" class="btn  btn-warning">Women</a></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="position-relative section_border_check">
        <div class="nav">
          <nav>
              <a href="#section1" class="active">HAIR</a>
              <a href="#section2">SKIN</a>
              <a href="#section3">BEAUTY</a>
              <a href="#section4">LASER</a>
              <a href="#section5">NAIL ART</a>
          </nav>
        </div>
        <div id="section1" class="section">
          <div class="container-fluid mb-5">
          <div class="row">
            <div class="col-12">
              <div>
                <h1 class="text-center mt-3 mb-3">HAIR</h1>
                <hr class="w-25 m-auto ">  
              </div>
            </div>
          </div>
        </div>
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-10 m-auto">
              <div class="container-fluid">
                <div class="row justify-content-center">
                  <div class="col-md-3 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom back_texture_round_head">
                        <h1 class="p-3 font-6 mb-0 font-w-600">Hair Styling</h1>
                        <div class="back_texture_round"></div>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Hair Cut</li>
                          <li>Oiling</li>
                          <li>Ironing</li>
                          <li>Global Coloring</li>
                          <li>Root Touch Up</li>
                          <li>Blow Dry</li>
                          <li>Head Massage</li>
                          <li>Roller Setting</li>
                          <li>Shampoo & Conditioning</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-3 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom back_texture_round_head">
                        <h1 class="p-3 font-6 mb-0 font-w-600">Hair Texture</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Rebonding</li>
                          <li>Perming</li>
                          <li>Keratin</li>
                          <li>Color Protection</li>
                          <li>Smoothening</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-3 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom back_texture_round_head">
                        <h1 class="p-3 font-6 mb-0 font-w-600">Hair Treatments</h1>
                        <div class="back_texture_round_two"></div>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Spa Treatments</li>
                          <li>Volumizing</li>
                          <li>Advanced Hair Moisturising</li>
                          <li>Scalp Treatments</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="section2" class="section">
        <div class="container-fluid mb-5">
          <div class="row">
            <div class="col-12">
              <div>
                <h1 class="text-center mt-3 mb-3">SKIN</h1>
                <hr class="w-25 m-auto ">  
              </div>
            </div>
          </div>
        </div>
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-10 m-auto">
              <div class="container-fluid">
                <div class="row justify-content-center">
                  <div class="col-md-3 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom back_texture_round_head">
                        <h1 class="p-3 font-6 mb-0 font-w-600">BLEACH</h1>
                        <div class="back_texture_round"></div>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <!-- <li>Jolen Bleach</li> -->
                          <li>Oxy Bleach</li>
                          <!-- <li>Pearl Bleach</li> -->
                          <li>Sara De-Tan</li>
                          <li>Cherryls Bleach</li>
                          <li>Oxy Life De-Tan</li>
                          <!-- <li>Front And Back Bleach</li> -->
                          <li>Arms Bleach</li>
                          <li>Legs Bleach</li>
                          <li>Body Bleach</li>
                          <li>Protein Bleach</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-3 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom back_texture_round_head">
                        <h1 class="p-3 font-6 mb-0 font-w-600">FACIALS</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <!-- <li>Clean Up</li> -->
                          <li>Lotus Facial</li>
                          <li>Naturals Facial</li>
                          <li>O3<sup>+</sup> Facial</li>
                          <li>Casmara Facial</li>
                          <li>Kanpeki Facial</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-3 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom back_texture_round_head">
                        <h1 class="p-3 font-6 mb-0 font-w-600">CLEAN UP</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Basic Clean Up</li>
                          <li>Lotus Clean Up</li>
                          <li>O3<sup>+</sup> Clean Up</li>
                          <!-- <li>Casmara Facial</li> -->
                          <li>Kanpeki Clean Up</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-3 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom">
                        <h1 class="p-3 font-6 mb-0 font-w-600">Facials & Rituals</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Bleach</li>
                          <li>Clean Ups</li>
                          <li>Luxury Facials/Rituals</li>
                          <li>Body Polishing/Rejuvenation</li>
                          <li>Threading</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-3 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom">
                        <h1 class="p-3 font-6 mb-0 font-w-600">HANDS & FEET</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Manicure</li>
                          <li>Pedicure</li>
                          <li>Nail Paint</li>
                          <li>French Nail Paint</li>
                          <li>Hands Bleach</li>
                          <li>Legs Bleach</li>
                          <li>Body Massage</li>
                          <li>Waxing</li>
                          <li>Spa Manicure</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-3 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom back_texture_round_head">
                        <h1 class="p-3 font-6 mb-0 font-w-600">WAXING</h1>
                        <div class="back_texture_round_two"></div>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Arms Waxing</li>
                          <li>Legs Waxing</li>
                          <li>Lower Arms</li>
                          <li>Back Waxing</li>
                          <li>Full Body Waxing</li>
                          <li>Bikini Wax</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="section3" class="section">
          <div class="container-fluid mb-5">
          <div class="row">
            <div class="col-12">
              <div>
                <h1 class="text-center mt-3 mb-3">BEAUTY</h1>
                <hr class="w-25 m-auto ">  
              </div>
            </div>
          </div>
        </div>
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-10 m-auto">
              <div class="container-fluid">
                <div class="row mb-3">
                  <div class="col-12 text-center">
                    <h3>WEDDING PACKAGES</h3>
                  </div>
                </div>
                <div class="row justify-content-center">
                  <div class="col-md-4 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom back_texture_round_head">
                        <h1 class="p-3 font-6 mb-0 font-w-600">Natural Silver Pre-Bride Package</h1>
                        <div class="back_texture_round"></div>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Threading Eyebrows</li>
                          <li>Threading Upper Lips</li>
                          <!-- <li>Herbal Bleach Face</li> -->
                          <li>Neck & Blouse Line</li>
                          <li>Bleach</li>
                          <!-- <li>Diamond Facial</li> -->
                          <li>Facial</li>
                          <li>Waxing Full Body</li>
                          <li>Body Polishing</li>
                          <li>Manicure</li>
                          <li>Pedicure</li>
                          <li>Style Change Hair Cut With Shampoo And Deep Conditioning</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom back_texture_round_head">
                        <h1 class="p-3 font-6 mb-0 font-w-600">The Gold Pre-Bride Package</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Threading Eyebrows</li>
                          <li>Threading Upper Lips</li>
                          <li>Bleach Face, Neck & Blouse Line - Gold</li>
                          <li>Premium Waxing Full Body</li>
                          <li>Full Body Polish</li>
                          <!-- <li>Gold Dazzle Facial</li> -->
                          <li>Manicure</li>
                          <li>Pedicure</li>
                          <!-- <li>Chrome/metallic Normal Polish</li> -->
                          <li>Body Polishing</li>
                          <li>Style Change Hair Cut With Shampoo</li>
                          <li>Hair Spa</li>
                          <!-- <li>Insta-glow Skin Re-surfacing</li> -->
                          <!-- <li>Therapy (Face & Neck)</li> -->
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom">
                        <h1 class="p-3 font-6 mb-0 font-w-600">The Exotic Pre-bride Package</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Threading Eyebrows</li>
                          <li>Threading Upper Lips</li>
                          <!-- <li>Bleach Face, Neck & Blouse Line - Gold</li> -->
                          <li>Bleach Face, Neck & Blouse Line</li>
                          <li>O3+ Facial</li>
                          <!-- <li>Premium Rica Waxing Full Body</li> -->
                          <li>Rica Waxing Full Body</li>
                          <li>Bleach Full Body</li>
                          <!-- <li>Bleach Full Body - Oxy</li> -->
                          <li>Skin Polishing</li>
                          <!-- <li>Full Body Skin Polish</li> -->
                          <li>Super Manicure</li>
                          <li>Super Pedicure</li>
                          <!-- <li>Chrome/Metallic Gel Polish</li> -->
                          <li>Style Change Hair Cut With Shampoo</li>
                          <li>Hair Spa</li>
                          <!-- <li>Insta-dazzle Skin Re-surfacing</li> -->
                          <!-- <li>Therapy (Face & Neck) (Face)</li> -->
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom">
                        <h1 class="p-3 font-6 mb-0 font-w-600">Make Up</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Party Make Up</li>
                          <li>Engagement Make Up</li>
                          <li>Bridal & Reception Make Up</li>
                          <li>Base Make Up</li>
                          <li>Eye Make Up</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row justify-content-center">
                  <hr>
                  <div class="col-md-4 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom">
                        <h1 class="p-3 font-6 mb-0 font-w-600">SILVER</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Bridal Consultation</li>
                          <li>Threading - Eyebrows Upperlips & Chin</li>
                          <li>Normal Waxing - Full Hands, Full Legs And Underarms</li>
                          <li>Basic - Face, Neck And Blouse Line</li>
                          <li>Classic Manicure</li>
                          <li>Classic Pedicure</li>
                          <li>Chocolate / Pearl Facial</li>
                          <li>Frizz Repair Hair Spa (Any Length)</li>
                          <li>Root Touch Up (Basic Shades Black / Brown - Igora Royal)</li>
                          <li>Hair Trim</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom">
                        <h1 class="p-3 font-6 mb-0 font-w-600">GOLD</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Bridal Consultation</li>
                          <li>Threading - Eyebrows Upperlips & Chin</li>
                          <li>Rica Waxing - Hands, Legs And Underarms</li>
                          <li>D-tan Face, Neck & Blouse Line</li>
                          <li>Spa Manicure</li>
                          <li>Spa Pedicure</li>
                          <li>Advanced Facial</li>
                          <li>Nourishing Spa</li>
                          <li>Full Body Scrub - Shower</li>
                          <li>Root Touch Up (Basic Shades Black/brown - Essentially)</li>
                          <li>Hair Cut</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom">
                        <h1 class="p-3 font-6 mb-0 font-w-600">PLATINUM</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Bridal Consultation</li>
                          <li>Threading - Eyebrows Upperlips & Chin</li>
                          <li>Rica Waxing - Full Body</li>
                          <li>D-tan Full Body</li>
                          <li>Manicure</li>
                          <li>Pedicure</li>
                          <li>Advanced Facial - O3<sup>+</sup> (2 Times)</li>
                          <li>Advanced Hair Cut</li>
                          <li>Face Mask (2 Days Before The Event)</li>
                          <li>Full Body Polishing + Shower</li>
                          <li>Nourishing Spa (2 Times)</li>
                          <li>Global Hair Coloring</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="section4" class="section">
          <div class="container-fluid mb-5">
          <div class="row">
            <div class="col-12">
              <div>
                <h1 class="text-center mt-3 mb-3">LASER</h1>
                <hr class="w-25 m-auto ">  
              </div>
            </div>
          </div>
        </div>
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-10 m-auto">
              <div class="container-fluid">
                <div class="row justify-content-center">
                  <div class="col-md-4 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom back_texture_round_head">
                        <h1 class="p-3 font-6 mb-0 font-w-600">Hair Loss</h1>
                        <div class="back_texture_round"></div>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Advanced Hair Treatment</li>
                          <li>Female pattern baldness</li>
                          <li>All hair conditions</li>
                          <li>Hair care products</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <!--<div class="col-md-3 mb-4 h-100">-->
                  <!--  <div class="main_card_service_area border rounded-5">-->
                  <!--    <div class="border-bottom back_texture_round_head">-->
                  <!--      <h1 class="p-3 font-6 mb-0 font-w-600">Skin</h1>-->
                  <!--    </div>-->
                  <!--    <div class="iinner_service_list">-->
                  <!--      <ul class="pt-3 pb-1">-->
                  <!--        <li>Acne</li>-->
                  <!--        <li>Eczema</li>-->
                  <!--        <li>Pasoriasis</li>-->
                  <!--        <li>Vitiligo</li>-->
                  <!--        <li>All Skin Conditions</li>-->
                  <!--        <li>Skin Treatments</li>-->
                  <!--        <li>Skin Allergies</li>-->
                  <!--      </ul>-->
                  <!--    </div>-->
                  <!--  </div>-->
                  <!--</div>-->
                  <div class="col-md-4 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom back_texture_round_head">
                        <h1 class="p-3 font-6 mb-0 font-w-600">Advance Laser Treatment</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Patch Test</li>
                          <li>Upper Lips Laser</li>
                          <li>Side Locks Laser</li>
                          <li>Forehead Laser</li>
                          <li>Full Face Laser</li>
                          <li>Chin Laser</li>
                          <li>Full Hands Laser</li>
                          <li>Full Legs Laser</li>
                          <li>Front Body Part Laser</li>
                          <li>Black & Blue Tattoo Remover Small</li>
                          <li>Colour Tattoo Remove</li>
                          <li>Back Body Part Laser</li>
                          <li>Bikini Body Part Laser</li>
                          <li>Full Body Part Laser</li>
                          <li>Three Body Part Laser</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom back_texture_round_head">
                        <h1 class="p-3 font-6 mb-0 font-w-600">Facial</h1>
                        <div class="back_texture_round"></div>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Hydra Facial</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="section5" class="section">
          <div class="container-fluid mb-5">
          <div class="row">
            <div class="col-12">
              <div>
                <h1 class="text-center mt-3 mb-3">NAIL ART</h1>
                <hr class="w-25 m-auto ">  
              </div>
            </div>
          </div>
        </div>
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-10 m-auto">
              <div class="container-fluid">
                <div class="row justify-content-center">
                  <div class="col-md-4 mb-4 h-100">
                    <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom">
                        <h1 class="p-3 font-6 mb-0 font-w-600">Nail Categories</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Natural Nail</li>
                          <li>Acrylic Extention (Nail paint single glitter)</li>
                          <li>French Nail Extention</li>
                          <li>Full Hand Glitter</li>
                          <li>Gel Nail Extention (with nail paint)</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 mb-4 h-100">
                     <div class="main_card_service_area border rounded-5">
                      <div class="border-bottom">
                        <h1 class="p-3 font-6 mb-0 font-w-600">Refilling</h1>
                      </div>
                      <div class="iinner_service_list">
                        <ul class="pt-3 pb-1">
                          <li>Natural Nail</li>
                          <li>Acrylic Nail</li>
                          <li>Gel Nail</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      </section>
      
      <section class="mb-5 pt-5">
        <div class="container">
          <div class="row mb-4">
            <div class="col-md-9 m-auto">
              <h6 class="fs-2 text-center">Book an Appointment</h6>
              <p class="font-6 text-center">If this is the first time you are booking an online appointment at Gliss, we suggest calling (01204134403) us directly so that we can understand your needs and better assist you with booking the proper time and service for you. </p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-9 m-auto">
              <!-- <form class="contact_form">
                <div class="row">
                  <div class="col-md-6">
                    <div class="mb-3">
                      <label class="form-label">Full Name</label>
                      <input type="text" class="form-control" placeholder="" required>
                    </div>
                    <div class="mb-3">
                      <label class="form-label">Email</label>
                      <input type="email" class="form-control" placeholder="" required>
                    </div>
                    <div class="mb-3">
                      <label class="form-label">Mobile</label>
                      <input type="number" class="form-control" placeholder="" required>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="mb-3">
                      <label class="form-label">Service Type</label>
                      <select class="form-control" id="serviceType" name="serviceType" aria-label="Floating label select example">
                        <option selected></option>
                        <option value="hair">Hair</option>
                        <option value="beauty">Beauty</option>
                        <option value="skin">Skin</option>
                        <option value="wellness">Wellness</option>
                      </select>
                    </div>
                    <div class="mb-3">
                      <label class="form-label">Preferred Date</label>
                      <input type="date" class="form-control" placeholder="" required>
                    </div>
                    <div class="mb-3">
                      <label class="form-label">Preferred Time</label>
                      <input type="time" class="form-control" placeholder="" required>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6 m-auto">
                    <div class="">
                      <input type="submit" class="main-btn w-100" value="Submit" required>
                    </div>
                  </div>
                </div>
              </form> -->
              <iframe  class="shrivraWidget" src="https://gliss.salonist.io/booking" style="width: 100%; max-width: 770px; min-height: 750px;border: none; margin:10px auto;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center!important;-ms-flex-pack:center!important;justify-content:center!important"></iframe>
            </div>
          </div>
        </div>
      </section>
      <!-- footer -->
      <div style="height: 50px;"></div>
      <?php include 'includes/footer.php'?>
      <!-- footer -->
      <!-- footer CDN links -->
      <?php include 'includes/footer_script.php'?>
      <!-- footer CDN links -->
      <script src="libraries/sweetalert/sweetalert.min.js"></script>
      <script type="text/javascript" id="salonistScript" src="https://gliss.salonist.io/js/booking-button.js"></script>
      <script type="text/javascript" src="https://qmixi.github.io/slide-nav/dist/slideNav.js"></script>
      <script type="text/javascript">
        window.slide = new SlideNav();
      </script>
   </body>
</html>