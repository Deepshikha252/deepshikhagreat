<?php include 'config.php'; ?>
<?php include 'header.php'; ?>
    <!-- content area -->

    <div class="inner_image_section" style="height: 170px;">
           <h1>About Us</h1> 
    </div>
    <div class="container mb-5">
      <div class="row">
        <div class="col-md-5">
          <div class="image_about_us_image">
            <img src="images/about.jpg" class="img-fluid">
          </div>
        </div>
        <div class="col-md-7">
          <div class="image_about_us_image">
            <h2 class="mb-4">About Our Shop</h2>
            <p class="mb-3">Antique Arts is, simply, all about the arts. We take great pride in culling out the most profound narratives from the past, and retelling them through the lens of vintage artifacts, home décor and handpicked collectibles.
              <br>
              No matter what form they take and where they go, the stories live on. Join us in giving these stories a new life.</p>
              <a href="contact.php" class="btn btn-primary">TALK TO US</a>
          </div>
        </div>
      </div>
    </div>


    <!-- content area -->
<?php include 'footer.php'?>
