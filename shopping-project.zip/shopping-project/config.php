<?php
  include 'admin/php_files/database.php';

  // $hostname = "http://localhost/shoppingproject-yb";
  $hostname = "http://localhost/shopping-project";
    
?>