<?php include 'config.php'; ?>
<?php include 'header.php'; ?>
    <!-- content area -->

    <div class="inner_image_section" style="height: 170px;">
           <h1>Contact Us</h1> 
    </div>
    <div class="container mb-5">
      <div class="row">
        <div class="col-md-5">
          <div class="image_about_us_image">
            <h3 class="mb-3">Antique Arts</h3>
             <h4 class="mb-1"><span><i class="fa fa-phone" aria-hidden="true"></i></span> &nbsp; +91 9319412012</h4>
             <h4 class="mb-1"><span><i class="fa fa-envelope" aria-hidden="true"></i></span> &nbsp; info@senseprojects.in</h4>
             <h4 class="mb-1"><span><i class="fa fa-map-marker" aria-hidden="true"></i></span> &nbsp; 17, Block A, Sector 4, Noida, <br> &nbsp; &nbsp; &nbsp; Uttar Pradesh 201301</h4>
             
          </div>
        </div>
        <div class="col-md-7">
          <div class="image_about_us_image">
            <h2 class="mb-4">How Can we help You</h2>
            <form method="post">
              <input type="" class="form-control mb-1" name="" placeholder="Full Name">
              <input type="" class="form-control mb-1" name="" placeholder="Email">
              <input type="" class="form-control mb-1" name="" placeholder="Subject">
              <textarea class="form-control mb-1"></textarea>
              <button class="btn btn-primary btn-block">Submit</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="container mb-5">
      <div class="row">
        <div class="col-md-12">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d875.9036615756714!2d77.32156952918064!3d28.5813321765788!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce450b69f04d5%3A0x7c6b67089fa03164!2s17%2C%20Block%20A%2C%20Sector%204%2C%20Noida%2C%20Uttar%20Pradesh%20201301!5e0!3m2!1sen!2sin!4v1664537899083!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>
    </div>


    <!-- content area -->
<?php include 'footer.php'?>
