<?php  
// $conn = mysqli_connect('localhost','root','', 'salon_db');
// if ($conn) {
//     echo 'ok';
// } else {
//     echo 'fail';
// }

// die();
// exit();

?>
<?php include 'config.php';  //include config
// set dynamic title
$db = new Database();
$db->select('options','site_title',null,null,null,null);
$result = $db->getResult();

if(!empty($result)){ 
    $title = $result[0]['site_title']; 
}else{ 
    $title = "Shopping Project";
}
// include header 
include 'header.php'; ?>
<!-- 
<div id="banner">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="banner-content ">
                    <div class="banner-carousel owl-carousel owl-theme">
                        <div class="item">
                            <img src="images/banner-img-2.jpg" alt=""/>
                        </div>
                        <div class="item">
                            <img src="images/banner-img-1.jpg" alt=""/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="images/Antique Artsheader.png" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
            <form action="search.php" method="GET" class="header-search-bar">
                <div class="input-group search">
                    <input type="text" class="form-control" name="search" placeholder="Search for...">
                    <span class="input-group-btn">
                        <input class="btn btn-default"  type="submit" value="Search" />
                    </span>
                </div>
                </form>
        </div>
      </div>
      <div class="carousel-item">
        <img src="images/Antique Artsheader.png" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h5>Second slide label</h5>
          <p>Some representative placeholder content for the second slide.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="images/Antique Artsheader.png" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h5>Third slide label</h5>
          <p>Some representative placeholder content for the third slide.</p>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>

<section class="">
    <div class="container ">
        <div class="row">
            <div class="col-md-12 text-center header-2-text">
                <h1>Antique Arts</h1>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>

            </div>
        </div>
    </div>
    
</section>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
    <path fill="rgb(229 246 253)" fill-opacity="1" d="M0,64L60,90.7C120,117,240,171,360,165.3C480,160,600,96,720,96C840,96,960,160,1080,181.3C1200,203,1320,181,1380,170.7L1440,160L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"></path>
</svg>
<div class="product-section popular-products">
   
    <div class="container-fluid desktop-products">
        <div class="row">
            <div class="col-md-12">
                <div class="heading-img">
                    <img src="images/Shop.png" class="img-fluid center">
                    <h2 class="section-head">Antique Gate</h2>
                </div>
                <div class=" text-right view-all mb-4">
                    <a>VIEW ALL</a>
                </div>
                <div class="popular-carousel owl-carousel owl-theme">
                    <?php
                        $db->select('products','*',null,'product_views > 0','product_views DESC',10);
                        $result = $db->getResult();
                        if(count($result) > 0){
                            foreach($result as $row){ ?>
                    <div class="product-grid latest item">
                        <div class="product-image popular">
                            <a class="image" href="single_product.php?pid=<?php echo $row['product_id']; ?>">
                                <img class="pic-1" src="product-images/<?php echo $row['featured_image']; ?>">
                            </a>
                            <div class="product-button-group">
                                <!-- <a href="single_product.php?pid=<?php echo $row['product_id']; ?>" ><i class="fa fa-eye"></i></a>
                                <a href="" class="add-to-cart" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-shopping-cart"></i></a>
                                <a href="" class="add-to-wishlist" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-heart"></i></a> -->
                            </div>
                        </div>
                        <div class="product-content">
                            <h3 class="title">
                                <a href="single_product.php?pid=<?php echo $row['product_id']; ?>"><?php echo substr($row['product_title'],0,25),'...'; ?></a>
                            </h3>
                            <div class="price"><?php echo $cur_format; ?> <?php echo $row['product_price']; ?></div>
                            <div class="add-to-cart-pr">
                                <a href="single_product.php?pid=<?php echo $row['product_id']; ?>" >&#x2022; ADD TO CART&#x2022; </a>
                            </div>
                            <div class="add-to-cart-w ">
                                <span > <a href="" class="add-to-wishlist" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-heart"></i>Add to wishlist</a></span>
                                <span> <a href="single_product.php?pid=<?php echo $row['product_id']; ?>" ><i class="fa fa-eye"></i>Quick View</a></span>
                            </div>
                        </div>
                    </div>



                    <?php    }
                    }else{
                } ?>
                </div>


                


                
            </div>
            

            
        </div>
    </div>


    

<!-- mobile products start -->

<div class="container mobile-products">
    <div class="row">
        <div class="col-md-12 ">
            <div class="heading-img">
                <img src="images/Shop.png" class="img-fluid center">
                <h2 class="section-head">Antique Gate</h2>
                
            </div>
            <div class=" text-right view-all">
                <a>VIEW ALL</a>
            </div>
        </div>
        
        <?php
        $limit = 8;
        $db->select('products','*',null,'product_views > 0','product_views DESC',4);
        $result = $db->getResult();
        if(count($result) > 0){
            foreach($result as $row){ ?>
                <div class="col">
                      <div class="product-grid latest item">
                        <div class="product-image popular">
                            <a class="image" href="single_product.php?pid=<?php echo $row['product_id']; ?>">
                                <img class="pic-1" src="product-images/<?php echo $row['featured_image']; ?>">
                            </a>
                            <div class="product-button-group">
                                <!-- <a href="single_product.php?pid=<?php echo $row['product_id']; ?>" ><i class="fa fa-eye"></i></a>
                                <a href="" class="add-to-cart" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-shopping-cart"></i></a>
                                <a href="" class="add-to-wishlist" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-heart"></i></a> -->
                            </div>
                        </div>
                        <div class="product-content">
                            <h3 class="title">
                                <a href="single_product.php?pid=<?php echo $row['product_id']; ?>"><?php echo substr($row['product_title'],0,25),'...'; ?></a>
                            </h3>
                            <div class="price"><?php echo $cur_format; ?> <?php echo $row['product_price']; ?></div>
                            <div class="add-to-cart-pr">
                                <a href="single_product.php?pid=<?php echo $row['product_id']; ?>" >&#x2022; ADD TO CART&#x2022; </a>
                            </div>
                            <div class="add-to-cart-w ">
                                <span > <a href="" class="add-to-wishlist" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-heart"></i>Add to wishlist</a></span>
                                <span> <a href="single_product.php?pid=<?php echo $row['product_id']; ?>" ><i class="fa fa-eye"></i>Quick View</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php    }
        }else{ ?>
            <div class="empty-result">Result Empty</div>
    <?php } ?>
    
    <div class="col-md-12 pagination-outer">
        <?php
            echo $db->pagination('products','*',null,null,'product_id DESC',10,$limit);;
        ?>
    </div>
    </div>
</div>









<!-- mobile products ends -->
</div>





<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" class="svg-bottom">
    <path fill="#fff" fill-opacity="1" d="M0,192L60,208C120,224,240,256,360,256C480,256,600,224,720,224C840,224,960,256,1080,266.7C1200,277,1320,267,1380,261.3L1440,256L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"></path>
  </svg>













<div class="product-section">
    <div class="container-fluid desktop-products">
        <div class="row">
            <div class="col-md-12">
                <div class="heading-img">
                    <img src="images/Shop.png" class="img-fluid center">
                    <h2 class="section-head">Antique Railing</h2>
                </div>
                <div class="latest-carousel owl-carousel owl-theme">
                    <?php
            $db = new Database();
            $db->select('products','*',null,null,'product_id DESC',6);
            $result = $db->getResult();
            if(count($result) > 0){
                foreach($result as $row){ ?>
                    <div class="product-grid latest item" style="    background: #ffcc00;
                    border-radius: 13px;">
                        <div class="product-image popular">
                            <a class="image" href="single_product.php?pid=<?php echo $row['product_id']; ?>">
                                <img class="pic-1" src="product-images/<?php echo $row['featured_image']; ?>">
                            </a>
                            <div class="product-button-group">
                                <!-- <a href="single_product.php?pid=<?php echo $row['product_id']; ?>" ><i class="fa fa-eye"></i></a>
                                <a href="" class="add-to-cart" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-shopping-cart"></i></a>
                                <a href="" class="add-to-wishlist" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-heart"></i></a> -->
                            </div>
                        </div>
                        <div class="product-content">
                            <h3 class="title">
                                <a href="single_product.php?pid=<?php echo $row['product_id']; ?>"><?php echo substr($row['product_title'],0,25),'...'; ?></a>
                            </h3>
                            <div class="price"><?php echo $cur_format; ?> <?php echo $row['product_price']; ?></div>
                            <div class="add-to-cart-pr">
                                <a style="background-color: #fff;" href="single_product.php?pid=<?php echo $row['product_id']; ?>" >&#x2022; ADD TO CART&#x2022; </a>
                            </div>
                            <div class="add-to-cart-w ">
                                <span > <a href="" class="add-to-wishlist" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-heart"></i>Add to wishlist</a></span>
                                <span> <a href="single_product.php?pid=<?php echo $row['product_id']; ?>" ><i class="fa fa-eye"></i>Quick View</a></span>
                            </div>
                        </div>
                    </div>
        <?php    }
            }?>
                </div>
            </div>
        </div>
    </div>


    <!-- mobile products start -->

<div class="container mobile-products">
    <div class="row">
        <div class="col-md-12 ">
            <div class="heading-img">
                <img src="images/Shop.png" class="img-fluid center">
                <h2 class="section-head">Antique Railing</h2>
                
            </div>
            <div class=" text-right view-all">
                <a>VIEW ALL</a>
            </div>
        </div>
        
        <?php
        $limit = 8;
        $db->select('products','*',null,'product_views > 0','product_views DESC',4);
        $result = $db->getResult();
        if(count($result) > 0){
            foreach($result as $row){ ?>
                <div class="col">
                      <div class="product-grid latest item"style="    background: #ffcc00;
                      border-radius: 13px;" >
                        <div class="product-image popular">
                            <a class="image" href="single_product.php?pid=<?php echo $row['product_id']; ?>">
                                <img class="pic-1" src="product-images/<?php echo $row['featured_image']; ?>">
                            </a>
                            <div class="product-button-group">
                                <!-- <a href="single_product.php?pid=<?php echo $row['product_id']; ?>" ><i class="fa fa-eye"></i></a>
                                <a href="" class="add-to-cart" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-shopping-cart"></i></a>
                                <a href="" class="add-to-wishlist" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-heart"></i></a> -->
                            </div>
                        </div>
                        <div class="product-content">
                            <h3 class="title">
                                <a href="single_product.php?pid=<?php echo $row['product_id']; ?>"><?php echo substr($row['product_title'],0,25),'...'; ?></a>
                            </h3>
                            <div class="price"><?php echo $cur_format; ?> <?php echo $row['product_price']; ?></div>
                            <div class="add-to-cart-pr">
                                <a style="background-color: #fff;"  href="single_product.php?pid=<?php echo $row['product_id']; ?>" >&#x2022; ADD TO CART&#x2022; </a>
                            </div>
                            <div class="add-to-cart-w ">
                                <span > <a href="" class="add-to-wishlist" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-heart"></i>Add to wishlist</a></span>
                                <span> <a href="single_product.php?pid=<?php echo $row['product_id']; ?>" ><i class="fa fa-eye"></i>Quick View</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php    }
        }else{ ?>
            <div class="empty-result">Result Empty</div>
    <?php } ?>
    
    <div class="col-md-12 pagination-outer">
        <?php
            echo $db->pagination('products','*',null,null,'product_id DESC',10,$limit);;
        ?>
    </div>
    </div>
</div>









<!-- mobile products ends -->
</div>

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
    <path fill="rgb(229 246 253)" fill-opacity="1" d="M0,64L60,90.7C120,117,240,171,360,165.3C480,160,600,96,720,96C840,96,960,160,1080,181.3C1200,203,1320,181,1380,170.7L1440,160L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"></path>
</svg>

<div class="product-section popular-products1">
   
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 heading-catogries text-center">
   <img src="images/Shop by.png" class="img-fluid">
   <h2 class="section-head1">Category</h2>
   <a><span>&#x2022;</span>VIEW ALL<span>&#x2022;</span></a>    
            </div>
            <div class="col-md-9 d-flex Category-content">
                <!-- <div>
                    <img src="images/Category1.png" class="img-fluid">
                    <h1>Antique Light</h1>
                </div>

                <div>
                    <img src="images/Category2.png" class="img-fluid">
                    <h1>Antique Photo Frame </h1>
                </div>
                <div>
                    <img src="images/Category3.png" class="img-fluid">
                    <h1>Antique Door</h1>
                </div>
                <div>
                    <img src="images/Category4.png" class="img-fluid">
                    <h1>Antique Watch</h1>
                </div>
                <div>
                    <img src="images/Category5.png" class="img-fluid">
                    <h1>Antique Pots</h1>
                </div> -->

                
<div class="home-demo">
    <div class="owl-carousel owl-theme">
      <div class="item">
       
            <img src="images/Category1.png" class="img-fluid">
            <h1>Antique Light</h1>
        
      </div>
      <div class="item">
        <div>
            <img src="images/Category2.png" class="img-fluid">
            <h1>Antique Photo Frame </h1>
        </div>
      </div>
      <div class="item">
        <div>
            <img src="images/Category3.png" class="img-fluid">
            <h1>Antique Door</h1>
        </div>
      </div>
      <div class="item">
        <div>
            <img src="images/Category4.png" class="img-fluid">
            <h1>Antique Watch</h1>
        </div>
      </div>
      <div class="item">
        <div>
            <img src="images/Category5.png" class="img-fluid">
            <h1>Antique Pots</h1>
        </div>
      </div>
    
    </div>
  </div>
            </div>
        </div>
    </div>
</div>

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" class="svg-bottom">
    <path fill="#fff" fill-opacity="1" d="M0,192L60,208C120,224,240,256,360,256C480,256,600,224,720,224C840,224,960,256,1080,266.7C1200,277,1320,267,1380,261.3L1440,256L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"></path>
  </svg>

  <section class="Featured-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading-img">
                    <img src="images/Featured.png" class="img-fluid center">
                    <h2 class="section-head2">Collections</h2>
                </div>
            </div>

            <div class="col-md-4 text-center Featured-content">
                <img src="images/Featured1.png" class="img-fluid">
                <h1>Antique Home Decor</h1>
                <div class="add-to-cart-pr">
                    <a href="" >&#x2022; SHOP NOW&#x2022; </a>
                </div>
            </div>

            <div class="col-md-4 text-center Featured-content">
                <img src="images/Featured2.png" class="img-fluid">
                <h1>Antique Home Decor</h1>
                <div class="add-to-cart-pr">
                    <a href="" >&#x2022; SHOP NOW&#x2022; </a>
                </div>
            </div>

            <div class="col-md-4 text-center Featured-content">
                <img src="images/Featured3.png" class="img-fluid">
                <h1>Antique Home Decor</h1>
                <div class="add-to-cart-pr">
                    <a href="" >&#x2022; SHOP NOW&#x2022; </a>
                </div>
            </div>
        </div>
    </div>
  </section>
<section class='message-content'>
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="leave-message">
                    <h1>Leave Us a Message</h1>
                    <p>Fill on information details to consult with us to get services form us</p>

                    <form>
                        <div class="form-group">
                         
                            <input type="name" class="form-control" id="name" aria-describedby="" placeholder="Name">
                           
                          </div>
                        <div class="form-group">
                         
                          <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email">
                         
                        </div>
                        <div class="form-group">
                         
                          <input  class="form-control" id="Phone" placeholder="Phone">
                        </div>

                        <div class="form-group">
                            <textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Enter your Message..." rows="3"></textarea>
                          </div>
                       
                          <div class="add-to-cart-message">
                            <a href="" > <span class="left-dot">&#x2022;</span> SUBMIT<span class="right-dot">&#x2022;</span> </a>
                        </div>
                      </form>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="Why-Us">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Why Choose Us</h1>
                <div class=" why-content">
                    <div class="content-1-why-us" style="display: flex;">
                        <img src="images/Whychooseus1.png" class="img-fluid">
                        <p>Same-day Local Delivery</p>
                    </div>

                    <div class="content-1-why-us" style="display: flex;">
                        <img src="images/Whychooseus2.png" class="img-fluid">
                        <p>Ground Shipping directly to you</p>
                    </div>

                    <div class="content-1-why-us" style="display: flex;">
                        <img src="images/Whychooseus3.png" class="img-fluid">
                        <p>Free in-store pick-up </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                
            </div>
        </div>
    </div>
</section>
<section id="slider" class="slider-test">
    <div class="container">
        <div class="heading-img">
            <img src="images/Testimonials.png" class="img-fluid center">
            <h2 class="section-head2">Customer Say</h2>
        </div>        
        <div class="slider">
                  <div class="owl-carousel" >
                      <div class="slider-card">
                          <div class="d-flex justify-content-center align-items-center mb-4">
                              <img src="images/slide-1.jpg" alt="" >
                          </div>
                          <h5 class="mb-0 text-center"><b>HTML CSS3 Tutorials</b></h5>
                          <p class="text-center p-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam temporibus quidem magni qui doloribus quasi natus inventore nisi velit minima.</p>
                      </div>
                      <div class="slider-card">
                          <div class="d-flex justify-content-center align-items-center mb-4">
                              <img src="images/slide-2.jpg" alt="">
                          </div>
                          <h5 class="mb-0 text-center"><b>Wordpress Tutorials</b></h5>
                          <p class="text-center p-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam temporibus quidem magni qui doloribus quasi natus inventore nisi velit minima.</p>
                      </div>
                      <div class="slider-card">
                          <div class="d-flex justify-content-center align-items-center mb-4">
                              <img src="images/slide-3.jpg" alt="">
                          </div>
                          <h5 class="mb-0 text-center"><b>PHP MySQL Tutorials</b></h5>
                          <p class="text-center p-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam temporibus quidem magni qui doloribus quasi natus inventore nisi velit minima.</p>
                      </div>
                      <div class="slider-card">
                          <div class="d-flex justify-content-center align-items-center mb-4">
                              <img src="images/slide-4.jpg" alt="">
                          </div>
                          <h5 class="mb-0 text-center"><b>Javascript Tutorials</b></h5>
                          <p class="text-center p-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam temporibus quidem magni qui doloribus quasi natus inventore nisi velit minima.</p>
                      </div>
                      <div class="slider-card">
                          <div class="d-flex justify-content-center align-items-center mb-4">
                              <img src="images/slide-5.jpg" alt="">
                          </div>
                          <h5 class="mb-0 text-center"><b>Bootstrap Tutorials</b></h5>
                          <p class="text-center p-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam temporibus quidem magni qui doloribus quasi natus inventore nisi velit minima.</p>
                      </div>
                  </div>
              </div>
    </div>
  </section>


  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
    <path fill="rgb(229 246 253)" fill-opacity="1" d="M0,64L60,90.7C120,117,240,171,360,165.3C480,160,600,96,720,96C840,96,960,160,1080,181.3C1200,203,1320,181,1380,170.7L1440,160L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"></path>
</svg>
<div class="FAQ">
   
    <div class="container">
        <div class="row">
      <div class="col-md-12">
        <div class="heading-img">
            <h2 class="section-head3">FAQ</h2>
        </div> 
        
        
        <div class="accordion" id="accordionExample">
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingOne">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                 <h5> Accordion Item #1</h5>
                </button>
              </h2>
              <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <strong>This is the first item's accordion body.</strong> It is shown by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingTwo">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    <h5> Accordion Item #1</h5>
                </button>
              </h2>
              <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <strong>This is the second item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingThree">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    <h5> Accordion Item #1</h5>
                </button>
              </h2>
              <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                </div>
              </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="headingFour">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                      <h5> Accordion Item #1</h5>
                  </button>
                </h2>
                <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                    <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                  </div>
                </div>
              </div>

              
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingFive">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                      <h5> Accordion Item #1</h5>
                  </button>
                </h2>
                <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                    <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                  </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="headingSix">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                      <h5> Accordion Item #1</h5>
                  </button>
                </h2>
                <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                    <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                  </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="headingSeven">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                      <h5> Accordion Item #1</h5>
                  </button>
                </h2>
                <div id="collapseSeven" class="accordion-collapse collapse" aria-labelledby="headingSeven" data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                    <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                  </div>
                </div>
            </div>

            
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingEight">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                      <h5> Accordion Item #1</h5>
                  </button>
                </h2>
                <div id="collapseEight" class="accordion-collapse collapse" aria-labelledby="headingEight" data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                    <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                  </div>
                </div>
            </div>
          </div>
      </div>
        </div>
    </div>
</div>




  <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" ></script> 
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" ></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/script.js"></script>
<script>$(function() {
    // Owl Carousel
    var owl = $(".owl-carousel");
    owl.owlCarousel({
      items: 5,
      margin: 0,
      loop: true,
      nav: true
    });
  });
  </script>
<?php include 'footer.php'; ?>

